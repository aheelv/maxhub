# -*- coding: utf-8 -*-
# 单元三范式 B：ReAct 单智能体（Thought -> Action -> Observation 循环）
import json, os

BASE = os.path.dirname(os.path.abspath(__file__))
MAX_STEPS = 5


try:
    _TICKETS = {t["ticket_id"]: t for t in json.load(
        open(os.path.join(BASE, "data", "tickets.json"), encoding="utf-8"))}
except FileNotFoundError:
    _TICKETS = {}


def lookup(tid):
    t = _TICKETS.get(tid, {"amount": 499, "days": 5})
    return {"amount": t["amount"], "days": t["days"], "status": "已签收"}


def risk_check(amount):
    return {"level": "high" if amount > 500 else "low"}


def refund(tid, amount):
    return {"refund_id": "RF-" + tid[-3:], "amount": amount}


TOOLS = {"lookup": lookup, "risk_check": risk_check, "refund": refund}


def decide(ticket, history):
    # 教学 MockLLM：按观察结果决定下一步；PROD 换成 Function Calling
    if not history:
        return ("需要订单事实", "lookup", {"tid": ticket["ticket_id"]})
    last = history[-1]
    if last["action"] == "lookup":
        return ("拿到金额，评估风险", "risk_check", {"amount": last["obs"]["amount"]})
    if last["action"] == "risk_check":
        if last["obs"]["level"] == "high":
            return ("高风险转人工", "escalate", {})
        amount = next((h["obs"]["amount"] for h in history if h["action"] == "lookup"), 499)
        return ("风险低，执行退款", "refund",
                {"tid": ticket["ticket_id"], "amount": amount})
    return ("信息充足，结束", "finish", {})


def run(ticket):
    history, steps = [], 0
    for _ in range(MAX_STEPS):
        thought, action, args = decide(ticket, history)
        steps += 1
        if action == "escalate":
            return {"decision": "human_review", "steps": steps, "trace": history, "loop": True}
        if action == "finish":
            return {"decision": "auto_approve", "steps": steps, "trace": history, "loop": True}
        obs = TOOLS[action](**args)
        history.append({"thought": thought, "action": action, "args": args, "obs": obs})
    return {"decision": "max_steps", "steps": steps, "trace": history, "loop": True}


if __name__ == "__main__":
    tickets = json.load(open(os.path.join(BASE, "data", "tickets.json"), encoding="utf-8"))
    r = run(tickets[0])
    print("决策：", r["decision"], "| 步数：", r["steps"], "| 轨迹：", len(r["trace"]))
