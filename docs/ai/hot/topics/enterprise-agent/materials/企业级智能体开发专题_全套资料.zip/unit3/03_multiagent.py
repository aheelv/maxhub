# -*- coding: utf-8 -*-
# 单元三范式 C：Supervisor 多智能体 + 共享状态 + HITL + checkpoint 断点续跑
import json, os

BASE = os.path.dirname(os.path.abspath(__file__))
CKPT = os.path.join(BASE, "checkpoint.json")
HIGH = 500


def triage(state):
    state["route"] = "refund" if "退款" in state["ticket"]["text"] or "退货" in state["ticket"]["text"] else "service"
    state["log"].append("triage -> " + state["route"])
    return state


def risk(state):
    state["risk"] = "high" if state["ticket"]["amount"] > HIGH or state["ticket"]["dispute"] else "low"
    state["log"].append("risk -> " + state["risk"])
    return state


def finance(state):
    state["proposal"] = {"amount": state["ticket"]["amount"], "action": "退款待审批"}
    state["log"].append("finance -> proposal")
    return state


def supervisor(state):
    if state.get("risk") == "high":
        state["need_human"] = True
        state["log"].append("supervisor -> interrupt(human)")
    else:
        state["need_human"] = False
        state["decision"] = "auto_approve"
        state["log"].append("supervisor -> approve")
    return state


ROLES = [triage, risk, finance, supervisor]


def run(ticket, auto_confirm=False):
    state = {"ticket": ticket, "log": [], "stage": 0}
    for i, role in enumerate(ROLES):
        state = role(state)
        state["stage"] = i + 1
        if role is supervisor and state["need_human"] and not auto_confirm:
            with open(CKPT, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False)
            return {"status": "interrupted", "checkpoint": CKPT, "state": state}
    state["decision"] = state.get("decision", "approved_after_human")
    return {"status": "done", "state": state}


def resume(approve=True):
    if not os.path.exists(CKPT):
        return {"error": "没有待恢复的 checkpoint"}
    state = json.load(open(CKPT, encoding="utf-8"))
    state["log"].append("human -> " + ("approve" if approve else "reject"))
    state["decision"] = "approved_after_human" if approve else "rejected_by_human"
    state["need_human"] = False
    os.remove(CKPT)
    return {"status": "done", "state": state}


if __name__ == "__main__":
    tickets = json.load(open(os.path.join(BASE, "data", "tickets.json"), encoding="utf-8"))
    hi = next(t for t in tickets if t["amount"] > HIGH)
    lo = next(t for t in tickets if t["amount"] <= HIGH and not t["dispute"])
    print("低风险：", run(lo)["state"]["decision"])
    r = run(hi)
    print("高风险：", r["status"], "| 日志：", r["state"]["log"])
    print("人工确认后：", resume(True)["state"]["decision"])
