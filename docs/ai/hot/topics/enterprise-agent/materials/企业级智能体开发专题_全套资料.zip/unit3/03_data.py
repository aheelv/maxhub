# -*- coding: utf-8 -*-
# 单元三：12 条虚构售后工单（覆盖正常 / 高金额 / 信息缺失 / 争议）
import json, os

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
os.makedirs(DATA, exist_ok=True)
TYPES = ["退货", "退款", "换货", "投诉", "发票", "价保"]
rows = []
amounts = [59, 268, 499, 899, 1280, 88, 320, 760, 45, 1580, 210, 680]
for i, a in enumerate(amounts, 1):
    rows.append({
        "ticket_id": "WD-%03d" % i,
        "order_id": "SO-2026-%03d" % ((i - 1) % 3 + 1),
        "type": TYPES[(i - 1) % len(TYPES)],
        "amount": a,
        "days": (i * 3) % 20,
        "text": "%s申请，金额 %d 元" % (TYPES[(i - 1) % len(TYPES)], a),
        "dispute": i in (4, 10),
        "missing_info": i == 7,
    })
with open(os.path.join(DATA, "tickets.json"), "w", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=2)
print("已生成 12 条工单 -> data/tickets.json")
