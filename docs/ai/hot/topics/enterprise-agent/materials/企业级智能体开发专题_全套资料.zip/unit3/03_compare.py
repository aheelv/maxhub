# -*- coding: utf-8 -*-
# 单元三：同一批 12 条工单，三种范式定量对照
import json, os
from importlib.util import spec_from_file_location, module_from_spec

BASE = os.path.dirname(os.path.abspath(__file__))


def _load(f, n):
    s = spec_from_file_location(n, os.path.join(BASE, f))
    m = module_from_spec(s)
    s.loader.exec_module(m)
    return m


WF, RE, MA = (_load("03_workflow.py", "wf"), _load("03_react.py", "re"),
              _load("03_multiagent.py", "ma"))


def main():
    tickets = json.load(open(os.path.join(BASE, "data", "tickets.json"), encoding="utf-8"))
    report = {"workflow": {"steps": 0, "human": 0, "auto": 0},
              "react": {"steps": 0, "human": 0, "auto": 0},
              "multiagent": {"steps": 0, "human": 0, "auto": 0}}
    for t in tickets:
        w = WF.run(t)
        report["workflow"]["steps"] += len(w["steps"])
        report["workflow"]["human"] += w["decision"] == "human_review"
        report["workflow"]["auto"] += w["decision"] == "auto_approve"
        r = RE.run(t)
        report["react"]["steps"] += r["steps"]
        report["react"]["human"] += r["decision"] == "human_review"
        report["react"]["auto"] += r["decision"] == "auto_approve"
        m = MA.run(t, auto_confirm=False)
        st = m["state"]
        report["multiagent"]["steps"] += len(st["log"])
        report["multiagent"]["human"] += m["status"] == "interrupted"
        report["multiagent"]["auto"] += m["status"] == "done" and st.get("decision") == "auto_approve"
    # 恢复残留 checkpoint，保证脚本可重复运行
    if os.path.exists(MA.CKPT):
        MA.resume(True)
    with open(os.path.join(BASE, "compare_report.json"), "w", encoding="utf-8") as f:
        json.dump({"tickets": len(tickets), "result": report}, f, ensure_ascii=False, indent=2)
    print("工单数：", len(tickets))
    for k, v in report.items():
        print("%-10s 节点/步数=%3d 人工确认=%2d 自动通过=%2d" %
              (k, v["steps"], v["human"], v["auto"]))
    print("-> compare_report.json")
    return report


if __name__ == "__main__":
    main()
