# -*- coding: utf-8 -*-
# 单元三范式 A：固定 Workflow（DAG），步骤确定、可审计、不能自主换路
# 节点：classify -> enrich -> decide -> execute -> reply
import json, os

BASE = os.path.dirname(os.path.abspath(__file__))


def run(ticket, tools=None):
    tools = tools or {"steps": 0}
    state = {"ticket": ticket, "steps": []}
    # 1 classify
    t = ticket["type"]
    state["route"] = "refund" if t in ("退货", "退款", "价保") else "service"
    state["steps"].append("classify")
    # 2 enrich
    state["amount"] = ticket["amount"]
    state["days"] = ticket["days"]
    state["steps"].append("enrich")
    # 3 decide（纯规则，无模型）
    if ticket["missing_info"]:
        state["decision"] = "ask_info"
    elif state["amount"] > 500 or ticket["dispute"]:
        state["decision"] = "human_review"
    elif state["route"] == "refund" and state["days"] <= 7:
        state["decision"] = "auto_approve"
    else:
        state["decision"] = "standard_process"
    state["steps"].append("decide")
    # 4 execute
    state["executed"] = {"decision": state["decision"], "auto": state["decision"] == "auto_approve"}
    state["steps"].append("execute")
    # 5 reply
    state["reply"] = "按固定流程处理：" + state["decision"]
    state["steps"].append("reply")
    tools["steps"] += len(state["steps"])
    return state


if __name__ == "__main__":
    tickets = json.load(open(os.path.join(BASE, "data", "tickets.json"), encoding="utf-8"))
    print(run(tickets[0])["reply"], "| 节点：", run(tickets[0])["steps"])
