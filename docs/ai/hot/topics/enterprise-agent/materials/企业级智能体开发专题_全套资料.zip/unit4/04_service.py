# -*- coding: utf-8 -*-
# 单元四：服务化（标准库 http.server 可跑；PROD 换 FastAPI，见 04_service_fastapi.py）
# 启动：python 04_service.py   然后：python 04_smoke_test.py
import json, os, threading, time
from collections import defaultdict, deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.util import spec_from_file_location, module_from_spec
from urllib.parse import urlparse

BASE = os.path.dirname(os.path.abspath(__file__))


def _load(f, n):
    s = spec_from_file_location(n, os.path.join(BASE, f))
    m = module_from_spec(s)
    s.loader.exec_module(m)
    return m


CORE, G, EVAL = (_load("04_agent_core.py", "c"), _load("04_guardrails.py", "g"),
                 _load("04_eval.py", "e"))
BUCKET = defaultdict(deque)
RATE = 30  # 每 IP 每分钟 30 次
START = time.time()


def rate_ok(ip):
    q = BUCKET[ip]
    now = time.time()
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= RATE:
        return False
    q.append(now)
    return True


def handle_chat(payload):
    q = str(payload.get("query", ""))
    gi = G.guard_input(q)
    G.audit("guard_input", query=q, **gi)
    if gi["block"]:
        return {"answer": "请求被护栏拦截：" + gi["reason"], "refused": True,
                "citations": [], "trace_id": ""}
    r = CORE.answer(q)
    go = G.guard_output(r["answer"])
    r["answer"] = go["text"]
    G.audit("answer", query=q, trace_id=r["trace_id"], redacted=go["redacted"])
    return r


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/health":
            return self._send(200, {"status": "ok", "uptime_s": round(time.time() - START, 1),
                                   "backend": "mock", "version": "1.0.0"})
        if path == "/eval":
            return self._send(200, EVAL.main())
        if path == "/metrics":
            return self._send(200, {"requests": sum(len(v) for v in BUCKET.values()),
                                    "rate_limit_per_min": RATE})
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        if not rate_ok(self.client_address[0]):
            return self._send(429, {"error": "rate limited"})
        if urlparse(self.path).path != "/chat":
            return self._send(404, {"error": "not found"})
        n = int(self.headers.get("Content-Length", 0))
        try:
            payload = json.loads(self.rfile.read(n).decode() or "{}")
        except Exception:
            return self._send(400, {"error": "invalid json"})
        return self._send(200, handle_chat(payload))


def serve(port=8765, block=True):
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    if block:
        print("服务已启动 http://127.0.0.1:%d  (/health /chat /eval /metrics)" % port)
        srv.serve_forever()
    return srv


if __name__ == "__main__":
    serve(int(os.getenv("PORT", "8765")))
