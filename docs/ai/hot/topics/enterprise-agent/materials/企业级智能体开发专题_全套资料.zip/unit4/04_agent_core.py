# -*- coding: utf-8 -*-
# 单元四：被评测与上线的最小智能体内核（浓缩单元二的检索/引用/工具能力）
import json, os, re, time, uuid

BASE = os.path.dirname(os.path.abspath(__file__))
POLICIES = [
    ("P1", "退换货时限：自签收之日起 7 日内可申请无理由退货；7 日以上、30 日以内仅支持质量问题换货。"),
    ("P2", "退款审核：单笔金额不超过 500 元的退款由客服主管审批；超过 500 元须风控复核后由财务审批。"),
    ("P3", "发货时效：现货商品付款后 24 小时内出库；预售商品以商品页标注的发货日期为准。"),
    ("P4", "价保规则：签收后 15 日内同款降价可申请一次价保，返还差额，需提供订单号。"),
    ("P5", "发票：电子发票在订单完成后 3 个工作日内开具，可在订单详情页下载。"),
    ("P6", "信息边界：客服仅可查询本人服务工单关联订单；不得向外部透露客户手机号、地址与支付信息。"),
    ("P7", "升级机制：涉及投诉、舆情或金额争议的工单，须创建工单并转人工，智能体不得自行承诺赔付。"),
]
ORDERS = {"SO-2026-001": {"status": "已发货", "amount": 268.0},
          "SO-2026-002": {"status": "待审核", "amount": 899.0},
          "SO-2026-003": {"status": "已签收", "amount": 59.0}}
KEYWORDS = {"P1": ["退货", "退换", "签收"], "P2": ["退款", "审批", "金额"],
            "P3": ["发货", "出库", "现货"], "P4": ["价保", "降价", "差价"],
            "P5": ["发票", "开票"], "P6": ["手机号", "地址", "支付信息", "隐私"],
            "P7": ["投诉", "争议", "赔付", "舆情"]}


def retrieve(q):
    hits = []
    for pid, text in POLICIES:
        score = sum(1 for k in KEYWORDS[pid] if k in q)
        if score:
            hits.append((score, pid, text))
    hits.sort(key=lambda x: -x[0])
    return hits[:2]


def answer(query):
    t0 = time.time()
    hits = retrieve(query)
    tid = uuid.uuid4().hex[:12]
    tools = []
    m = re.search(r"SO-\d{4}-\d{3}", query)
    if m and m.group(0) in ORDERS:
        tools.append({"name": "get_order", "result": ORDERS[m.group(0)]})
    if not hits and not tools:
        out = {"answer": "抱歉，没有可依据的制度条款或业务数据，我不能作答；已转人工。",
               "citations": [], "refused": True, "tools": tools}
    else:
        body = ("依据公司制度：\n" + "\n".join("[%s] %s" % (p, t) for _, p, t in hits)) \
            if hits else "以下答复来自业务系统查询结果："
        if tools:
            body += "\n订单查询：" + json.dumps(tools[0]["result"], ensure_ascii=False)
        out = {"answer": body, "citations": [p for _, p, _ in hits],
               "refused": False, "tools": tools}
    out.update({"trace_id": tid, "latency_ms": round((time.time() - t0) * 1000, 2),
                "tokens": len(query) + len(out["answer"]), "cost": 0.0})
    return out


if __name__ == "__main__":
    print(json.dumps(answer("签收 5 天可以退货吗"), ensure_ascii=False, indent=2))
