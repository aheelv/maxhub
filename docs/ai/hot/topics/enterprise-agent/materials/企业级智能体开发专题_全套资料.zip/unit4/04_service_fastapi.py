# -*- coding: utf-8 -*-
# 生产替换点示例：同样的三个路由换成 FastAPI（需 pip install fastapi uvicorn）
# 教学主流程不依赖本文件；未安装依赖时本文件仅作为阅读示例。
try:
    from fastapi import FastAPI, HTTPException
    from pydantic import BaseModel
except ImportError:
    raise SystemExit("示例文件：请先 pip install fastapi uvicorn 后再运行")

from importlib.util import spec_from_file_location, module_from_spec
import os

BASE = os.path.dirname(os.path.abspath(__file__))
s = spec_from_file_location("svc", os.path.join(BASE, "04_service.py"))
svc = module_from_spec(s)
s.loader.exec_module(svc)
app = FastAPI(title="星辰电商企业服务智能体", version="1.0.0")


class ChatIn(BaseModel):
    query: str


@app.get("/health")
def health():
    return {"status": "ok", "backend": "mock"}


@app.post("/chat")
def chat(body: ChatIn):
    if not svc.rate_ok("fastapi"):
        raise HTTPException(429, "rate limited")
    return svc.handle_chat(body.model_dump())


@app.get("/eval")
def eval_report():
    return svc.EVAL.main()


# uvicorn 04_service_fastapi:app --host 0.0.0.0 --port 8000
