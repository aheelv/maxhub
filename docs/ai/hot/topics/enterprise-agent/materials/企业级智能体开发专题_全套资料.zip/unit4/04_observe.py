# -*- coding: utf-8 -*-
# 单元四：结构化 trace（生产可替换为 OpenTelemetry / Langfuse）
import json, os, time, uuid

BASE = os.path.dirname(os.path.abspath(__file__))
TRACE = os.path.join(BASE, "traces.jsonl")


class Span:
    def __init__(self, name, trace_id=None, **kw):
        self.name, self.trace_id = name, trace_id or uuid.uuid4().hex[:12]
        self.kw, self.t0 = kw, time.time()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        row = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "trace_id": self.trace_id,
               "span": self.name, "duration_ms": round((time.time() - self.t0) * 1000, 2)}
        row.update(self.kw)
        with open(TRACE, "a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    with Span("chat", user="u001", channel="web") as s:
        with Span("retrieve", trace_id=s.trace_id, hits=2):
            time.sleep(0.01)
        with Span("tool.get_order", trace_id=s.trace_id, ok=True):
            time.sleep(0.01)
    print("trace 已写入", TRACE)
