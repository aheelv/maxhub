# -*- coding: utf-8 -*-
# 单元四：离线评测集 + 指标（准确率 / 拒答 / 引用 / 延迟 / 成本）
import json, os, statistics
from importlib.util import spec_from_file_location, module_from_spec

BASE = os.path.dirname(os.path.abspath(__file__))


def _load(f, n):
    s = spec_from_file_location(n, os.path.join(BASE, f))
    m = module_from_spec(s)
    s.loader.exec_module(m)
    return m


CORE, G = _load("04_agent_core.py", "core"), _load("04_guardrails.py", "g")


def run_one(case):
    q = case["query"]
    gi = G.guard_input(q)
    if gi["block"]:
        r = {"answer": "请求被护栏拦截：" + gi["reason"], "citations": [],
             "refused": True, "tools": [], "latency_ms": 0.0, "tokens": len(q), "cost": 0.0}
    else:
        r = CORE.answer(q)
        if "手机号" in q or "地址" in q or "支付信息" in q:
            r["refused"] = True
    cite_ok = (not case["expect_cite"]) or (case["expect_cite"] in r["citations"])
    refuse_ok = r["refused"] == case["expect_refuse"]
    return {"id": case["id"], "type": case["type"], "pass": cite_ok and refuse_ok,
            "cite_ok": cite_ok, "refuse_ok": refuse_ok,
            "latency_ms": r["latency_ms"], "tokens": r["tokens"]}


def main():
    cases = json.load(open(os.path.join(BASE, "data", "evalset.json"), encoding="utf-8"))
    rows = [run_one(c) for c in cases]
    lat = [r["latency_ms"] for r in rows]
    report = {
        "total": len(rows), "passed": sum(r["pass"] for r in rows),
        "accuracy": round(sum(r["pass"] for r in rows) / len(rows), 3),
        "citation_hit": round(sum(r["cite_ok"] for r in rows) / len(rows), 3),
        "refuse_accuracy": round(sum(r["refuse_ok"] for r in rows) / len(rows), 3),
        "p95_latency_ms": round(sorted(lat)[int(len(lat) * .95) - 1], 2),
        "total_tokens": sum(r["tokens"] for r in rows),
        "estimated_cost_cny": 0.0,
        "cases": rows,
    }
    with open(os.path.join(BASE, "eval_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print("评测：%d/%d 通过 | 引用命中 %.2f | 拒答准确 %.2f | P95 %.2f ms"
          % (report["passed"], report["total"], report["citation_hit"],
             report["refuse_accuracy"], report["p95_latency_ms"]))
    print("-> eval_report.json")
    return report


if __name__ == "__main__":
    main()
