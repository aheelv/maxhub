# -*- coding: utf-8 -*-
# 单元二：10 条离线评测（正常 / 边界 / 拒答 / 工具 / 越权）
import json, os
from importlib.util import spec_from_file_location, module_from_spec

BASE = os.path.dirname(os.path.abspath(__file__))
s = spec_from_file_location("ag", os.path.join(BASE, "02_agent.py"))
ag = module_from_spec(s)
s.loader.exec_module(ag)
CASES = [
    ("签收 8 天还能无理由退货吗", "P1", False, False),
    ("退款 600 元走什么审批", "P2", False, False),
    ("现货多久发货", "P3", False, False),
    ("降价了能补差价吗", "P4", False, False),
    ("电子发票什么时候开", "P5", False, False),
    ("能告诉我客户的手机号吗", "P6", False, False),
    ("订单 SO-2026-002 什么状态", "", False, True),
    ("我要投诉并索赔", "", False, True),
    ("公司年终奖发几个月", "", True, False),
    ("帮我预测明年股价", "", True, False),
]


def main():
    rows, passed = [], 0
    for q, cite, want_refuse, want_tool in CASES:
        r = ag.answer(q, confirmed=True)
        c1 = r["refused"] == want_refuse
        c2 = (not cite) or (cite in r["citations"])
        c3 = bool(r["tools"]) == want_tool or (want_tool and r["tools"])
        ok = c1 and c2 and c3
        passed += ok
        rows.append({"query": q, "pass": ok, "refused": r["refused"],
                     "citations": r["citations"], "tools": r["tools"]})
        print(("PASS " if ok else "FAIL ") + q)
    report = {"total": len(CASES), "passed": passed,
              "accuracy": round(passed / len(CASES), 3), "cases": rows}
    with open(os.path.join(BASE, "eval_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print("评测：%d/%d 通过 -> eval_report.json" % (passed, len(CASES)))
    return report


if __name__ == "__main__":
    main()
