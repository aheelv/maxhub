# -*- coding: utf-8 -*-
# 单元二：BM25 检索 + 相关性阈值（决定「答」还是「拒答」）
import json, math, os
from importlib.util import spec_from_file_location, module_from_spec

BASE = os.path.dirname(os.path.abspath(__file__))
_s = spec_from_file_location("ing", os.path.join(BASE, "02_ingest.py"))
_m = module_from_spec(_s)
_s.loader.exec_module(_m)
tokenize = _m.tokenize
IDX = json.load(open(os.path.join(BASE, "index.json"), encoding="utf-8"))
MIN_SCORE = 1.2


def bm25(query, k=3):
    q = tokenize(query)
    scores = []
    for c in IDX["chunks"]:
        tf, dl = {}, len(c["tokens"])
        for t in c["tokens"]:
            tf[t] = tf.get(t, 0) + 1
        s = 0.0
        for t in q:
            if t not in tf:
                continue
            idf = math.log(1 + (IDX["n"] - IDX["df"].get(t, 0) + 0.5) /
                           (IDX["df"].get(t, 0) + 0.5))
            denom = tf[t] + IDX["k1"] * (1 - IDX["b"] + IDX["b"] * dl / IDX["avgdl"])
            s += idf * tf[t] * (IDX["k1"] + 1) / denom
        scores.append((s, c))
    scores.sort(key=lambda x: -x[0])
    return [{"id": c["id"], "text": c["text"], "score": round(s, 3)}
            for s, c in scores[:k] if s > 0]


def retrieve(query, k=3):
    hits = bm25(query, k)
    if not hits or hits[0]["score"] < MIN_SCORE:
        return {"ok": False, "hits": hits, "reason": "知识库无可靠依据，触发拒答"}
    return {"ok": True, "hits": hits, "reason": ""}


if __name__ == "__main__":
    for q in ["签收 8 天还能退货吗", "退款 800 元谁审批", "帮我查一下公司年终奖"]:
        r = retrieve(q)
        print(q, "=>", "可答" if r["ok"] else "拒答",
              [(h["id"], h["score"]) for h in r["hits"]])
