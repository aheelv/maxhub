# -*- coding: utf-8 -*-
# 单元二：业务工具 = JSON Schema + 参数校验 + 只读/写分离 + 幂等键
import os, re, sqlite3

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "data", "orders.db")
OID = re.compile(r"^SO-\d{4}-\d{3}$")
ORDER_SCHEMA = {"order_id": {"type": "string", "pattern": r"^SO-\d{4}-\d{3}$"}}
ITEM_SCHEMA = {"item": {"type": "string", "maxLength": 30}}
TICKET_SCHEMA = {"order_id": ORDER_SCHEMA["order_id"], "reason": {"type": "string", "maxLength": 120},
                 "idem_key": {"type": "string", "maxLength": 40}}


def _validate(name, schema, args):
    for k, rule in schema.items():
        if k not in args:
            raise ValueError(name + " 缺少参数 " + k)
        v = args[k]
        if rule["type"] == "string" and not isinstance(v, str):
            raise ValueError(name + "." + k + " 必须是字符串")
        if "pattern" in rule and not re.match(rule["pattern"], v):
            raise ValueError(name + "." + k + " 格式不合法")
        if "maxLength" in rule and len(v) > rule["maxLength"]:
            raise ValueError(name + "." + k + " 超长")


def get_order(args):
    """只读：查订单"""
    _validate("get_order", ORDER_SCHEMA, args)
    con = sqlite3.connect(DB)
    row = con.execute("SELECT order_id,item,amount,status,days FROM orders WHERE order_id=?",
                      (args["order_id"],)).fetchone()
    con.close()
    return {"found": bool(row), "order": dict(zip(
        ["order_id", "item", "amount", "status", "days"], row)) if row else None}


def check_inventory(args):
    """只读：查库存"""
    _validate("check_inventory", ITEM_SCHEMA, args)
    con = sqlite3.connect(DB)
    row = con.execute("SELECT stock FROM inventory WHERE item=?", (args["item"],)).fetchone()
    con.close()
    return {"item": args["item"], "stock": row[0] if row else 0}


def create_ticket(args):
    """写入：创建工单，带幂等键，重复调用不会产生两张工单"""
    _validate("create_ticket", TICKET_SCHEMA, args)
    con = sqlite3.connect(DB)
    exists = con.execute("SELECT ticket_id FROM tickets WHERE idem_key=?",
                         (args["idem_key"],)).fetchone()
    if exists:
        con.close()
        return {"created": False, "ticket_id": exists[0], "note": "幂等命中，未重复创建"}
    tid = "TK-" + str(abs(hash(args["idem_key"])) % 100000).zfill(5)
    con.execute("INSERT INTO tickets VALUES (?,?,?,?,?)",
                (tid, args["order_id"], args["reason"], "待人工处理", args["idem_key"]))
    con.commit()
    con.close()
    return {"created": True, "ticket_id": tid, "state": "待人工处理"}


TOOLS = {
    "get_order": {"schema": ORDER_SCHEMA, "handler": get_order, "write": False},
    "check_inventory": {"schema": ITEM_SCHEMA, "handler": check_inventory, "write": False},
    "create_ticket": {"schema": TICKET_SCHEMA, "handler": create_ticket, "write": True,
                      "need_confirm": True},
}


def call(name, args, confirmed=False):
    if name not in TOOLS:
        return {"error": "工具不在白名单：" + name}
    t = TOOLS[name]
    if t["write"] and t.get("need_confirm") and not confirmed:
        return {"error": "写入类工具需人工确认（HITL）"}
    try:
        _validate(name, t["schema"], args)
        return t["handler"](args)
    except Exception as e:
        return {"error": str(e)}


if __name__ == "__main__":
    print(call("get_order", {"order_id": "SO-2026-001"}))
    print(call("get_order", {"order_id": "bad-id"}))
    print(call("create_ticket", {"order_id": "SO-2026-001", "reason": "投诉", "idem_key": "k1"}))
    print(call("create_ticket", {"order_id": "SO-2026-001", "reason": "投诉", "idem_key": "k1"},
               confirmed=True))
    print(call("create_ticket", {"order_id": "SO-2026-001", "reason": "投诉", "idem_key": "k1"},
               confirmed=True))
    print(call("drop_table", {}))
