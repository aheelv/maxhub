# -*- coding: utf-8 -*-
# 单元二：生成虚构业务库。运行：python 02_data.py
import os, sqlite3

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
os.makedirs(DATA, exist_ok=True)
DB = os.path.join(DATA, "orders.db")
con = sqlite3.connect(DB)
con.executescript("""
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS tickets;
CREATE TABLE orders(order_id TEXT PRIMARY KEY, item TEXT, amount REAL, status TEXT, days INTEGER);
CREATE TABLE inventory(item TEXT PRIMARY KEY, stock INTEGER);
CREATE TABLE tickets(ticket_id TEXT PRIMARY KEY, order_id TEXT, reason TEXT, state TEXT, idem_key TEXT UNIQUE);
INSERT INTO orders VALUES
 ('SO-2026-001','无线耳机',268.0,'已发货',2),
 ('SO-2026-002','扫地机器人',899.0,'待审核',0),
 ('SO-2026-003','数据线',59.0,'已签收',9);
INSERT INTO inventory VALUES ('无线耳机',42),('扫地机器人',7),('数据线',310);
""")
con.commit()
print("已生成", DB, "| 订单 3 条 / 库存 3 条 / 工单表就绪")
con.close()
