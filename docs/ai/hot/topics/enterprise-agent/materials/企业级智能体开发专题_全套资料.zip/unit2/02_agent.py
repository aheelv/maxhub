# -*- coding: utf-8 -*-
# 单元二：知识助手 = 检索（带引用/拒答）+ 工具调用 + 轨迹留痕
import json, os, re
from importlib.util import spec_from_file_location, module_from_spec

BASE = os.path.dirname(os.path.abspath(__file__))


def _load(fname, name):
    s = spec_from_file_location(name, os.path.join(BASE, fname))
    m = module_from_spec(s)
    s.loader.exec_module(m)
    return m


RET = _load("02_retrieve.py", "ret")
TOOL = _load("02_tools.py", "tool")


def answer(query, confirmed=False):
    r = RET.retrieve(query)
    trace = {"query": query, "retrieved": r["hits"], "tools": []}
    # 事实类查询优先走受控工具；只有「既无制度依据、又无业务数据」才拒答
    m = re.search(r"SO-\d{4}-\d{3}", query)
    if m:
        obs = TOOL.call("get_order", {"order_id": m.group(0)})
        trace["tools"].append({"name": "get_order", "observation": obs})
    if "投诉" in query or "争议" in query:
        obs = TOOL.call("create_ticket", {"order_id": m.group(0) if m else "SO-2026-001",
                                           "reason": query[:60], "idem_key": "demo-" + str(abs(hash(query)) % 9999)},
                        confirmed=confirmed)
        trace["tools"].append({"name": "create_ticket", "observation": obs})
    if not r["ok"] and not trace["tools"]:
        out = {"answer": "抱歉，现有制度中没有可依据的条款，我也没有查到业务数据，不能凭空作答；已为您转人工。",
               "citations": [], "refused": True, "tools": [], "trace": trace}
    else:
        cites = ["[%s] %s" % (h["id"], h["text"]) for h in r["hits"][:2]]
        body = ("依据公司制度：\n" + "\n".join(cites)) if r["ok"] else "以下答复来自业务系统查询结果："
        for t in trace["tools"]:
            body += "\n%s：" % t["name"] + json.dumps(t["observation"], ensure_ascii=False)
        out = {"answer": body, "citations": [h["id"] for h in r["hits"][:2]],
               "refused": False, "tools": [t["name"] for t in trace["tools"]], "trace": trace}
    with open(os.path.join(BASE, "runs.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(out, ensure_ascii=False) + "\n")
    return out


if __name__ == "__main__":
    for q in ["签收 8 天还能无理由退货吗？", "退款 800 元需要谁审批？",
              "订单 SO-2026-002 现在什么状态？", "公司年终奖发几个月？"]:
        r = answer(q, confirmed=True)
        print("\nQ:", q)
        print("A:", r["answer"].replace("\n", " | "))
        print("引用:", r["citations"], "| 拒答:", r["refused"], "| 工具:", r["tools"])
