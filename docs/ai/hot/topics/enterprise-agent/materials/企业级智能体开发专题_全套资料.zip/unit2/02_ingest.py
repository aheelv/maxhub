# -*- coding: utf-8 -*-
# 单元二：文档切分 + 本地索引（BM25 预备，纯标准库）。运行：python 02_ingest.py
import json, math, os, re

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, "data", "policies.md")
OUT = os.path.join(BASE, "index.json")


def tokenize(text):
    # 中文按 2-gram，英文/数字按词；教学用，生产可换 tokenizer + embedding
    text = text.lower()
    words = re.findall(r"[a-z0-9]+", text)
    zh = re.findall(r"[\u4e00-\u9fff]+", text)
    grams = []
    for seg in zh:
        grams += [seg[i:i + 2] for i in range(len(seg) - 1)] or [seg]
    return words + grams


def split(path):
    chunks = []
    for line in open(path, encoding="utf-8"):
        m = re.match(r"^\[(P\d+)\]\s*(.+)$", line.strip())
        if m:
            chunks.append({"id": m.group(1), "text": m.group(2)})
    return chunks


def build():
    chunks = split(SRC)
    for c in chunks:
        c["tokens"] = tokenize(c["text"])
    df = {}
    for c in chunks:
        for t in set(c["tokens"]):
            df[t] = df.get(t, 0) + 1
    n = len(chunks)
    avg = sum(len(c["tokens"]) for c in chunks) / max(n, 1)
    idx = {"chunks": [{"id": c["id"], "text": c["text"], "tokens": c["tokens"]} for c in chunks],
           "df": df, "n": n, "avgdl": avg, "k1": 1.5, "b": 0.75}
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(idx, f, ensure_ascii=False)
    print("切分 %d 条制度条款 -> %s | 平均长度 %.1f token | 词表 %d" % (n, OUT, avg, len(df)))
    return idx


if __name__ == "__main__":
    build()
