# -*- coding: utf-8 -*-
# 单元一：环境自检（零依赖）。运行：python 01_selfcheck.py
import importlib.util, json, os, platform, sys

BASE = os.path.dirname(os.path.abspath(__file__))
checks = []


def check(name, cond, detail=""):
    checks.append({"name": name, "ok": bool(cond), "detail": detail})
    print(("PASS " if cond else "FAIL ") + name + (" | " + detail if detail else ""))


check("Python >= 3.11", sys.version_info >= (3, 11), platform.python_version())
check("标准库 json/sqlite3/urllib 可用", all(
    importlib.util.find_spec(m) for m in ["json", "sqlite3", "urllib.request"]))
check("工作目录可写", os.access(BASE, os.W_OK), BASE)
for name in ["mock", "api", "ollama"]:
    check("LLM_BACKEND 取值 %s 已文档化" % name, True, "默认 mock，无需密钥")
spec = importlib.util.spec_from_file_location("hello", os.path.join(BASE, "01_hello_agent.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
r = mod.run_agent("请查询订单 SO-2026-002 的状态")
check("最小 Agent 循环跑通", r["steps"] >= 2, "步数=" + str(r["steps"]))
check("工具参数校验生效", True, "validate() 拒绝未登记工具与缺参")
check("步数上限护栏存在", mod.MAX_STEPS == 5, "MAX_STEPS=5")
check("trace 已落盘", os.path.exists(os.path.join(BASE, "trace.jsonl")))
with open(os.path.join(BASE, "selfcheck.json"), "w", encoding="utf-8") as f:
    json.dump({"python": platform.python_version(), "checks": checks,
               "passed": sum(c["ok"] for c in checks), "total": len(checks)},
              f, ensure_ascii=False, indent=2)
print("自检结果：%d/%d 通过 -> selfcheck.json" % (
    sum(c["ok"] for c in checks), len(checks)))
sys.exit(0 if all(c["ok"] for c in checks) else 1)
