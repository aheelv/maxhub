# -*- coding: utf-8 -*-
# 单元一：最小但完整的企业级智能体循环（只用标准库）
# 运行：python 01_hello_agent.py
# 切换真实模型：LLM_BACKEND=api 并配置 API_BASE / API_KEY / MODEL
import json, os, time, urllib.request

BASE = os.path.dirname(os.path.abspath(__file__))
MAX_STEPS = 5
LLM_BACKEND = os.getenv("LLM_BACKEND", "mock")

# 虚构企业数据：订单与库存
ORDERS = {
    "SO-2026-001": {"status": "已发货", "amount": 268.0, "item": "无线耳机", "days": 2},
    "SO-2026-002": {"status": "待审核", "amount": 899.0, "item": "扫地机器人", "days": 0},
    "SO-2026-003": {"status": "已签收", "amount": 59.0, "item": "数据线", "days": 9},
}
INVENTORY = {"无线耳机": 42, "扫地机器人": 7, "数据线": 310}

# 工具注册表：企业级智能体的第一道边界是「只有登记过的工具能被调用」
TOOLS = {
    "get_order": {
        "description": "按订单号查询订单状态、金额与商品",
        "schema": {"order_id": "str"},
        "handler": lambda a: ORDERS.get(a["order_id"], {"error": "订单不存在"}),
    },
    "check_inventory": {
        "description": "按商品名查询当前可售库存",
        "schema": {"item": "str"},
        "handler": lambda a: {"item": a["item"], "stock": INVENTORY.get(a["item"], 0)},
    },
    "finish": {
        "description": "结束循环并给出最终答复",
        "schema": {"answer": "str"},
        "handler": lambda a: {"answer": a["answer"]},
    },
}


def validate(name, args):
    if name not in TOOLS:
        raise ValueError("未登记的工具：" + name)
    need = TOOLS[name]["schema"]
    for k in need:
        if k not in args:
            raise ValueError("缺少参数：" + k)
    return True


def mock_decide(goal, history):
    # 教学用 MockLLM：用确定性规则模拟「模型决定下一步调用哪个工具」
    # PROD: 换成真实模型的 Function Calling，输出结构保持 {thought, tool, args}
    if not history:
        if "SO-" in goal:
            oid = goal.split("SO-")[1][:11].strip()
            oid = "SO-" + oid.split()[0] if oid else "SO-2026-001"
            return {"thought": "用户问订单，先查订单", "tool": "get_order", "args": {"order_id": oid}}
        return {"thought": "无订单号，直接说明能力边界", "tool": "finish",
                "args": {"answer": "请提供订单号（形如 SO-2026-001），我再为您查询。"}}
    obs = history[-1]["observation"]
    if isinstance(obs, dict) and "status" in obs:
        return {"thought": "已拿到订单状态，结合库存给出答复", "tool": "check_inventory",
                "args": {"item": obs.get("item", "无线耳机")}}
    facts = [h["observation"] for h in history]
    return {"thought": "信息已足够，结束循环", "tool": "finish",
            "args": {"answer": "依据工具查询结果：" + json.dumps(facts, ensure_ascii=False)}}


def api_decide(goal, history):
    # PROD: OpenAI 兼容 /chat/completions + tools（同样只用标准库 urllib）
    base = os.getenv("API_BASE", "https://api.deepseek.com/v1")
    key = os.getenv("API_KEY", "")
    if not key:
        raise RuntimeError("LLM_BACKEND=api 需要 API_KEY；未配置时可继续用 mock")
    tools = [{"type": "function", "function": {
        "name": n, "description": v["description"],
        "parameters": {"type": "object", "properties": {
            k: {"type": "string"} for k in v["schema"]}, "required": list(v["schema"])}}}
        for n, v in TOOLS.items()]
    body = {"model": os.getenv("MODEL", "deepseek-chat"),
            "messages": [{"role": "user", "content": goal}], "tools": tools}
    req = urllib.request.Request(base + "/chat/completions", data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + key})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.loads(r.read().decode())
    call = data["choices"][0]["message"].get("tool_calls", [{}])[0]
    fn = call.get("function", {"name": "finish", "arguments": "{}"})
    return {"thought": "模型返回的下一步", "tool": fn["name"], "args": json.loads(fn["arguments"])}


def decide(goal, history):
    if LLM_BACKEND == "api":
        try:
            return api_decide(goal, history)
        except Exception as e:
            print("[fallback] 真实模型不可用，回退 MockLLM：", e)
    return mock_decide(goal, history)


def run_agent(goal, max_steps=MAX_STEPS):
    """感知 -> 决策 -> 执行 -> 观察 -> 终止；每一步都留 trace，步数有硬上限。"""
    history, trace, answer = [], [], None
    for i in range(1, max_steps + 1):
        d = decide(goal, history)
        validate(d["tool"], d["args"])
        t0 = time.time()
        observation = TOOLS[d["tool"]]["handler"](d["args"])
        row = {"step": i, "thought": d["thought"], "tool": d["tool"], "args": d["args"],
               "observation": observation, "ms": round((time.time() - t0) * 1000, 2)}
        trace.append(row)
        history.append(row)
        print("[%d] %s -> %s(%s) => %s" % (
            i, d["thought"], d["tool"], json.dumps(d["args"], ensure_ascii=False),
            json.dumps(observation, ensure_ascii=False)))
        if d["tool"] == "finish":
            answer = observation["answer"]
            break
    if answer is None:
        answer = "已达到最大步数上限，转人工处理（防死循环护栏生效）。"
    with open(os.path.join(BASE, "trace.jsonl"), "w", encoding="utf-8") as f:
        for row in trace:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    return {"answer": answer, "steps": len(trace), "trace": trace}


if __name__ == "__main__":
    print("=== 示例 A：带订单号的查询 ===")
    r1 = run_agent("请查询订单 SO-2026-001 的状态")
    print("最终答复：", r1["answer"], "| 步数：", r1["steps"])
    print("=== 示例 B：缺少关键信息 ===")
    r2 = run_agent("我的订单到哪了")
    print("最终答复：", r2["answer"], "| 步数：", r2["steps"])
