# 企业级智能体开发专题 · 全套资料

4 个 90 分钟单元的全部代码、样例数据、评测集与部署配置。
本资料包与课程网页内嵌代码逐字一致，可离线使用。

## 零障碍运行

- 只需 Python 3.11+ 与标准库，不需要账号、API Key 或联网。
- 每个单元目录可独立运行；按顺序进入目录执行即可。
- 默认使用内置 MockLLM，用规则模拟模型的工具决策，用来演示智能体循环、
  检索引用、多智能体协同与评测。切换到真实模型见各单元的「生产替换点」。

## 建议执行顺序

```
cd unit1 && python 01_selfcheck.py && python 01_hello_agent.py
cd ../unit2 && python 02_data.py && python 02_ingest.py && python 02_agent.py && python 02_eval.py
cd ../unit3 && python 03_data.py && python 03_workflow.py && python 03_react.py && python 03_multiagent.py && python 03_compare.py
cd ../unit4 && python 04_agent_core.py && python 04_guardrails.py && python 04_observe.py && python 04_eval.py && python 04_smoke_test.py
```

## 目录说明

| 目录 | 内容 |
| --- | --- |
| unit1 | 最小智能体循环、环境自检、trace 日志 |
| unit2 | 制度语料、SQLite 业务库、BM25 索引、三个受控工具、知识助手与 10 条评测 |
| unit3 | 12 条工单、Workflow / ReAct / 多智能体三种实现与对照评测 |
| unit4 | 护栏、评测集与指标、结构化 trace、HTTP 服务、冒烟测试、容器配置 |

企业名「星辰电商」、订单、金额、制度条款与工单均为课堂虚构数据。
