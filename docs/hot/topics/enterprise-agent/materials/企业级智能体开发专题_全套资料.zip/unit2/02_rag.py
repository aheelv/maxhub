# -*- coding: utf-8 -*-
"""单元二 · 知识底座：Document -> 切分 -> LangChain BaseRetriever（简化 BM25）。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.lc import build_retriever, format_docs, read_text, write_json

text = read_text("unit2/data/policies.md")
retriever = build_retriever(text, source="policies.md")
print("切分后的文档数：", len(retriever.docs))
for d in retriever.docs:
    print("  #%s %s" % (d.metadata["chunk"], d.page_content[:46]))

queries = ["签收 8 天还能无理由退货吗", "签收 3 天可以无理由退货吗", "公司股票怎么买"]
report = []
for q in queries:
    hits = retriever.search(q)
    kept = retriever.invoke(q)          # BaseRetriever 标准接口，可直接进 LCEL
    print("\n问：%s" % q)
    print("  最高分 %.3f，阈值 %.2f，命中 %d 条" % (hits[0][1], retriever.min_score, len(kept)))
    print("  引用：%s" % (format_docs(kept)[:100] or "（无可依据文档，触发拒答）"))
    report.append({"query": q, "best": hits[0][1], "kept": len(kept)})
write_json("unit2/chunks.json", {"chunks": len(retriever.docs), "queries": report})
print("\n生产替换：CourseRetriever -> Chroma + EnsembleRetriever + rerank")
