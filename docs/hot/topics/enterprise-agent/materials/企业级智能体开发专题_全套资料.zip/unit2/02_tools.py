# -*- coding: utf-8 -*-
"""单元二 · 工具接入：@tool / JSON Schema / 白名单 / HITL / 幂等键。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.lc import call_tool, tool_schemas

print("暴露给模型的工具 Schema：")
for name, schema in tool_schemas().items():
    print("  %-15s %s" % (name, sorted(schema)))

ledger = {}
cases = [
    ("get_order", {"order_id": "A100"}, False),      # 只读，放行
    ("check_refund", {"ticket_id": "T001"}, False),  # 只读，放行
    ("drop_table", {"name": "orders"}, False),      # 不在白名单，拦截
    ("create_refund", {"ticket_id": "T001", "amount": 299}, False),  # 写操作未确认，拦截
    ("create_refund", {"ticket_id": "T001", "amount": 299}, True),   # 人工确认后放行
    ("create_refund", {"ticket_id": "T001", "amount": 299}, True),   # 重复提交，幂等
]
for name, args, approved in cases:
    r = call_tool(name, args, approved=approved, ledger=ledger)
    print("%-14s approved=%-5s -> %s" % (name, approved, r))
print("\n写操作账本（幂等键）：", list(ledger))
