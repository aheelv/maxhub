# -*- coding: utf-8 -*-
"""单元二 · 带引用的答复链：输入护栏 + RunnableParallel 并行组装上下文与业务事实。"""
import sys
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.lc import (build_retriever, call_tool, format_docs, guard_input,
                       mock_llm, read_text)

from langchain_core.runnables import RunnableLambda, RunnableParallel

retriever = build_retriever(read_text("unit2/data/policies.md"), source="policies.md")


def lookup(inp):
    """只读工具：问题里出现订单号时查询业务系统，作为第二来源。"""
    import re
    m = re.search(r"A\d{3}", inp["question"])
    if not m:
        return []
    r = call_tool("get_order", {"order_id": m.group(0)})
    return [r["result"]] if r.get("ok") else []


def compose(inp):
    """离线「模型」：一个 LangChain Runnable，负责按来源组织答复与拒答。
    生产替换：ChatPromptTemplate | ChatOpenAI(...) | StrOutputParser()
    """
    if inp.get("blocked"):
        return {"answer": "请求已被输入护栏拦截：" + inp["reason"]
                          + "。售后智能体只处理订单、退换货与价保。",
                "citations": [], "refused": True}
    ctx, facts = inp["context"], inp["facts"]
    if not ctx and not facts:
        return {"answer": "知识库与业务系统均无可靠依据，已转人工。", "citations": [], "refused": True}
    cites = [c.split("]")[0] + "]" for c in ctx.split("\n") if c.strip()]
    body = ("依据公司制度：\n" + ctx) if ctx else "以下答复来自业务系统查询结果：\n" + json.dumps(facts, ensure_ascii=False)
    return {"answer": body, "citations": cites, "refused": False}


# 全链由 LangChain Runnable 组成：① 输入护栏 -> ② 检索与只读工具（并行）
# -> ③ 组装上下文 -> ④ 离线模型生成带引用的答复
chain = RunnableLambda(lambda x: {
    "question": x["question"], "guard": guard_input(x["question"]),
}) | RunnableParallel(
    question=RunnableLambda(lambda x: x["question"]),
    blocked=RunnableLambda(lambda x: x["guard"]["block"]),
    reason=RunnableLambda(lambda x: x["guard"]["reason"]),
    context=RunnableLambda(lambda x: "" if x["guard"]["block"]
                           else format_docs(retriever.invoke(x["question"]))),
    facts=RunnableLambda(lambda x: [] if x["guard"]["block"]
                         else lookup({"question": x["question"]})),
) | mock_llm(compose)

for q in ["签收 8 天还能无理由退货吗", "查询订单 A100 的状态", "帮我买一支股票"]:
    r = chain.invoke({"question": q})
    print("\n问：%s\n答：%s\n引用：%s 拒答：%s" % (q, r["answer"][:110], r["citations"], r["refused"]))


def answer(question: str) -> dict:
    return chain.invoke({"question": question})
