# 企业级智能体开发专题 · LangChain 演示资料

一条主线贯穿四个单元：围绕「星辰电商售后智能体」，用 LangChain 从最小链走到可评测、可上线。
每个单元 90 分钟（讲授 45 + 实践 45），全部脚本离线可跑、无需 API Key、结果可复现。

## 1. 环境（一次完成，四单元通用）

    python -m venv .venv
    # Windows: .venv\Scripts\activate    macOS/Linux: source .venv/bin/activate
    pip install -r requirements.txt
    python unit1/01_setup.py          # 期望：自检 10/10 通过

要求 Python 3.11+。教学主线只用 langchain / langchain-core 的本地脚本模型，
不需要任何付费账号；真实模型、向量库、FastAPI 都在「生产替换点」中给出。

## 2. 目录

    common/lc.py                 公共件：离线脚本模型、LangChain 检索器、工具白名单、trace、业务数据
    unit1/01_setup.py            环境自检（10/10）
    unit1/01_minimal_chain.py    最小 LCEL 链：Prompt | Model | Parser
    unit2/data/policies.md       售后制度语料
    unit2/02_rag.py              Document + 切分 + BaseRetriever（简化 BM25）
    unit2/02_tools.py            @tool + JSON Schema + 白名单 + HITL + 幂等
    unit2/02_agent.py            RunnableParallel 组装带引用的 RAG 答复链
    unit2/02_eval.py             10 条离线评测（引用 / 拒答 / 不编造）
    unit3/data/tickets.json      12 条售后工单
    unit3/03_workflow.py         固定 DAG（RunnableLambda + RunnableBranch）
    unit3/03_react_agent.py      create_tool_calling_agent + AgentExecutor（离线跑通）
    unit3/03_multi_agent.py      Supervisor 多角色协作
    unit3/03_compare.py          同一批工单三种实现对照
    unit4/data/evalset.json      黄金评测集（正常 / 边界 / 对抗 / 越权）
    unit4/04_core.py             汇总完整链
    unit4/04_guardrails.py       输入 / 检索 / 工具 / 输出 / 审计 五处护栏
    unit4/04_observe.py          BaseCallbackHandler 采集 trace
    unit4/04_eval.py             六项指标评测
    unit4/04_service.py          标准库 HTTP 服务（/health /ask /eval）
    unit4/04_service_fastapi.py  FastAPI 版（可选，需额外安装）
    unit4/04_smoke_test.py       上线冒烟 5/5
    unit4/Dockerfile / docker-compose.yml / 04_上线检查单.md

## 3. 建议执行顺序（照做即可，无需其它材料）

    cd unit1 && python 01_setup.py && python 01_minimal_chain.py
    cd ../unit2 && python 02_rag.py && python 02_tools.py && python 02_agent.py && python 02_eval.py
    cd ../unit3 && python 03_workflow.py && python 03_react_agent.py && python 03_multi_agent.py && python 03_compare.py
    cd ../unit4 && python 04_core.py && python 04_guardrails.py && python 04_observe.py && python 04_eval.py && python 04_smoke_test.py

## 4. 生产替换点（教学实现 → 企业级实现）

| 教学实现 | 生产替换 | 所在单元 |
| --- | --- | --- |
| `FakeListChatModel` / `ScriptedChatModel` | `init_chat_model(...)` / `ChatOpenAI(...)` / `ChatDeepSeek(...)` | 一 |
| `CourseRetriever`（简化 BM25） | `Chroma` / `Milvus` / `pgvector` + `EnsembleRetriever` + rerank | 二 |
| `RunnableLambda` 固定分支 | `LangGraph` 状态图 + checkpoint + HITL interrupt | 三 |
| `TraceCallback`（内存 trace） | LangSmith / Langfuse / OpenTelemetry | 四 |
| 标准库 HTTP 服务 | FastAPI + Uvicorn + Docker + K8s + 灰度 | 四 |
