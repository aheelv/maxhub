# -*- coding: utf-8 -*-
"""课程公共件：全部基于 LangChain 核心抽象，离线、可复现、无需 API Key。

生产替换点见 README.md。教学里有且只有一处「假模型」，其余编排、检索、
工具、解析、回调全部是真实的 LangChain 组件。
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.documents import Document
from langchain_core.language_models.fake_chat_models import (
    FakeListChatModel,
    FakeMessagesListChatModel,
)
from langchain_core.messages import AIMessage
from langchain_core.retrievers import BaseRetriever
from langchain_core.runnables import RunnableLambda
from langchain_core.tools import tool
from langchain_text_splitters import RecursiveCharacterTextSplitter
from pydantic import Field

ROOT = Path(__file__).resolve().parents[1]


# ---------------------------------------------------------------- 1. 模型
class ScriptedChatModel(FakeMessagesListChatModel):
    """按脚本依次返回 AIMessage（可含 tool_calls），让 AgentExecutor 离线跑通。

    生产替换：init_chat_model("deepseek-chat") 或 ChatOpenAI(model=...)。
    """

    def bind_tools(self, tools, **kwargs):
        # 离线模型不接受真实工具绑定；工具白名单由 AgentExecutor / call_tool 控制
        return self


def text_model(responses: Sequence[str]):
    """最简单的 LCEL 文本模型：按顺序返回固定字符串。"""
    return FakeListChatModel(responses=list(responses))


def scripted(responses):
    return ScriptedChatModel(responses=list(responses))


def ai(content: str, tool_calls=None):
    return AIMessage(content=content, tool_calls=tool_calls or [])


def tool_call(name: str, args: Dict[str, Any], cid: str = "call_1"):
    return {"name": name, "args": args, "id": cid, "type": "tool_call"}


def mock_llm(fn):
    """把确定性的离线「模型」包装成 LangChain Runnable，可直接用 | 串进链。

    生产替换：把这一节换成 ChatOpenAI(...) 即可，上下游链不用改。
    """
    return RunnableLambda(fn)


# ---------------------------------------------------------------- 2. 数据
ORDERS = {
    "A100": {"order_id": "A100", "status": "已签收", "amount": 299, "item": "蓝牙耳机", "days": 3},
    "A101": {"order_id": "A101", "status": "已签收", "amount": 899, "item": "扫地机器人", "days": 9},
    "A102": {"order_id": "A102", "status": "运输中", "amount": 159, "item": "保温杯", "days": 0},
}


def read_text(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def read_json(rel: str):
    return json.loads(read_text(rel))


def tickets() -> List[dict]:
    return read_json("unit3/data/tickets.json")


def evalset() -> List[dict]:
    return read_json("unit4/data/evalset.json")


# ---------------------------------------------------------------- 3. 检索
def tokens(text: str) -> List[str]:
    """中文 1 字 + 2gram、英文/数字词，够用于课堂规模语料。"""
    text = text.lower()
    out = re.findall(r"[a-z0-9]+", text)
    for seg in re.findall(r"[\u4e00-\u9fff]+", text):
        out.extend(list(seg))
        out.extend(seg[i:i + 2] for i in range(len(seg) - 1))
    return out


class CourseRetriever(BaseRetriever):
    """简化 BM25 检索器：继承 LangChain BaseRetriever，可直接进入 LCEL。

    生产替换：Chroma / Milvus / pgvector + EnsembleRetriever + CrossEncoder rerank。
    """

    docs: List[Document] = Field(default_factory=list)
    k: int = 3
    min_score: float = 0.8

    def search(self, query: str) -> List[Tuple[Document, float]]:
        if not self.docs:
            return []
        q = tokens(query)
        per_doc = [tokens(d.page_content) for d in self.docs]
        n = len(per_doc)
        avg = max(1.0, sum(len(t) for t in per_doc) / n)
        df = Counter()
        for t in per_doc:
            df.update(set(t))
        k1, b = 1.5, 0.75
        scored = []
        for idx, t in enumerate(per_doc):
            tf = Counter(t)
            s = 0.0
            for w in q:
                idf = math.log(1 + (n - df.get(w, 0) + 0.5) / (df.get(w, 0) + 0.5))
                s += idf * (tf[w] * (k1 + 1)) / (tf[w] + k1 * (1 - b + b * len(t) / avg))
            scored.append((self.docs[idx], round(s, 4)))
        scored.sort(key=lambda x: -x[1])
        return scored

    def _get_relevant_documents(self, query: str, *, run_manager=None) -> List[Document]:
        return [d for d, s in self.search(query) if s >= self.min_score][: self.k]


def build_retriever(text: str, source: str = "policies.md") -> CourseRetriever:
    """Document -> RecursiveCharacterTextSplitter -> BaseRetriever，全 LangChain。"""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=120, chunk_overlap=20,
        separators=["\n\n", "\n", "。", "；", " "],
    )
    docs = splitter.create_documents([text], metadatas=[{"source": source}])
    for i, d in enumerate(docs):
        d.metadata["chunk"] = i + 1
    return CourseRetriever(docs=docs, k=2, min_score=0.8)


def format_docs(docs: Sequence[Document]) -> str:
    return "\n".join(
        "[%s#%s] %s" % (d.metadata.get("source", "?"), d.metadata.get("chunk", "?"), d.page_content)
        for d in docs
    )


# ---------------------------------------------------------------- 3.5 输入护栏
OUT_OF_SCOPE = [
    "股票", "基金", "期货", "彩票", "虚拟币", "赌博",
    "删掉", "删除数据库", "清空表", "管理员身份", "重置他人",
    "忽略以上", "绕开制度", "绕过制度", "直接编", "直接承诺赔付",
]


def guard_input(question: str) -> dict:
    """① 输入护栏：范围外 / 越权 / 注入请求在检索之前就拦截，避免检索出无关片段后硬答。

    生产替换：把关键词表换成分类器 + 领域白名单 + 速率限制。
    """
    if len(question) > 200:
        return {"block": True, "reason": "输入超长"}
    for k in OUT_OF_SCOPE:
        if k in question:
            return {"block": True, "reason": "范围外或越权请求（" + k + "）"}
    return {"block": False, "reason": ""}


# ---------------------------------------------------------------- 4. 工具
@tool
def get_order(order_id: str) -> dict:
    """按订单号查询订单状态、金额、商品与签收天数（只读）。"""
    return ORDERS.get(order_id, {"error": "订单不存在"})


@tool
def check_refund(ticket_id: str) -> dict:
    """按工单号查询售后处理状态与可退金额（只读）。"""
    for t in tickets():
        if t["ticket_id"] == ticket_id:
            return {"ticket_id": ticket_id, "status": t["status"], "amount": t["amount"]}
    return {"error": "工单不存在"}


@tool
def create_refund(ticket_id: str, amount: float) -> dict:
    """创建退款单（写操作，必须人工确认）。"""
    return {"ok": True, "ticket_id": ticket_id, "amount": amount, "refund_id": "R-" + ticket_id}


TOOL_MAP = {t.name: t for t in (get_order, check_refund, create_refund)}
WRITE_TOOLS = {"create_refund"}


def tool_schemas() -> Dict[str, dict]:
    """工具清单即 JSON Schema，交给模型前先做白名单。"""
    return {name: t.args for name, t in TOOL_MAP.items()}


def call_tool(name: str, args: Dict[str, Any], *, approved: bool = False,
              ledger: dict = None) -> dict:
    """统一执行入口：白名单 -> 参数校验 -> 写操作 HITL -> 幂等键 -> 审计。"""
    if name not in TOOL_MAP:
        return {"block": True, "reason": "工具不在白名单内"}
    if not isinstance(args, dict):
        return {"block": True, "reason": "参数必须是对象"}
    if name in WRITE_TOOLS and not approved:
        return {"block": True, "reason": "写操作需人工确认（HITL）"}
    key = name + "|" + json.dumps(args, sort_keys=True, ensure_ascii=False)
    if name in WRITE_TOOLS and ledger is not None and key in ledger:
        return {"ok": True, "idempotent": True, "result": ledger[key]}
    result = TOOL_MAP[name].invoke(args)
    if name in WRITE_TOOLS and ledger is not None:
        ledger[key] = result
    return {"ok": True, "idempotent": False, "result": result}


# ---------------------------------------------------------------- 5. 观测
class TraceCallback(BaseCallbackHandler):
    """最小 trace：chain / tool 的开始与结束。生产替换为 LangSmith / Langfuse。"""

    def __init__(self):
        self.events: List[dict] = []

    def _add(self, kind, name, payload=None):
        self.events.append({"kind": kind, "name": name, "payload": payload or {}})

    def on_chain_start(self, serialized, inputs, **kwargs):
        self._add("chain_start", (serialized or {}).get("name", "chain"), {"inputs": str(inputs)[:120]})

    def on_chain_end(self, outputs, **kwargs):
        self._add("chain_end", "chain", {"outputs": str(outputs)[:120]})

    def on_tool_start(self, serialized, input_str, **kwargs):
        self._add("tool_start", (serialized or {}).get("name", "tool"), {"input": str(input_str)[:120]})

    def on_tool_end(self, output, **kwargs):
        self._add("tool_end", "tool", {"output": str(output)[:120]})


def write_json(rel: str, data) -> Path:
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return p
