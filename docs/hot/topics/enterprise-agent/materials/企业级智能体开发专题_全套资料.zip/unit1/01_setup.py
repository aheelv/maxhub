# -*- coding: utf-8 -*-
"""单元一 · 环境自检：10 项断言，全过才算环境就绪。"""
import json
import sys

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))
from common.lc import (ScriptedChatModel, ai, build_retriever, tool_schemas,
                       text_model, write_json)

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
import langchain
import langchain_core

checks = []


def ck(name, fn):
    try:
        ok = bool(fn())
    except Exception as e:
        ok = False
        name += " (%s)" % type(e).__name__
    checks.append({"item": name, "ok": ok})


ck("Python >= 3.11", lambda: sys.version_info >= (3, 11))
ck("langchain 已安装", lambda: langchain.__version__.startswith("0.3"))
ck("langchain-core 已安装", lambda: langchain_core.__version__.startswith("0.3"))
ck("ChatPromptTemplate 可用", lambda: "q" in ChatPromptTemplate.from_template("{q}").input_variables)
ck("StrOutputParser 可用", lambda: StrOutputParser().parse("ok") == "ok")
ck("LCEL 最小链可运行", lambda: (
    ChatPromptTemplate.from_template("{q}") | text_model(["ok"]) | StrOutputParser()
).invoke({"q": "hi"}) == "ok")
ck("离线脚本模型支持 bind_tools", lambda: isinstance(
    ScriptedChatModel(responses=[ai("ok")]).bind_tools([]), ScriptedChatModel))
ck("LangChain 检索器可用", lambda: len(build_retriever("第一条 签收7日内可退货。").docs) > 0)
ck("工具 Schema 完整", lambda: set(tool_schemas()) == {"get_order", "check_refund", "create_refund"})
ck("语料与评测集就位", lambda: len(__import__("common.lc", fromlist=["tickets"]).tickets()) == 12)

passed = sum(1 for c in checks if c["ok"])
print("自检结果：%d/%d 通过" % (passed, len(checks)))
for c in checks:
    print("  %s %s" % ("OK " if c["ok"] else "BAD", c["item"]))
write_json("unit1/selfcheck.json", {"passed": passed, "total": len(checks), "checks": checks})
assert passed == len(checks), "环境未就绪，请检查 pip install -r requirements.txt"
