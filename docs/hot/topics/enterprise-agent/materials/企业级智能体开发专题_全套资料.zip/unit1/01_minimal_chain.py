# -*- coding: utf-8 -*-
"""单元一 · 最小 LCEL 链：Prompt | Model | Parser，并挂上回调观测。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.lc import text_model, TraceCallback

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

prompt = ChatPromptTemplate.from_messages([
    ("system", "你是星辰电商的售后助手，只依据给定信息作答，语气简洁。"),
    ("human", "用户问题：{question}\n已知信息：{facts}"),
])
model = text_model(["依据已知信息：订单 A100 已签收 3 天，符合 7 日无理由退货条件。"])
parser = StrOutputParser()

# LCEL：用 | 把「提示词 -> 模型 -> 解析」串成一个 Runnable，可直接 invoke / batch / stream
chain = prompt | model | parser

trace = TraceCallback()
cfg = {"callbacks": [trace]}
answer = chain.invoke(
    {"question": "签收 3 天能退吗？", "facts": "订单 A100 已签收 3 天"},
    config=cfg,
)
print("答复：", answer)
print("trace 事件：", [e["kind"] for e in trace.events])
print("可替换点：把 model 换成 ChatOpenAI(model='gpt-4o-mini')，上下游不变。")
