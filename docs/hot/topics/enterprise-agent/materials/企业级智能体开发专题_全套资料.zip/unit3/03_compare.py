# -*- coding: utf-8 -*-
"""单元三 · 同一批 12 条工单，三种实现的成本与可预测性对照。"""
import sys
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from common.lc import tickets, write_json

def load(name):
    spec = spec_from_file_location(name.replace(".py", ""), str(HERE / name))
    m = module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

wf = load("03_workflow.py")
ma = load("03_multi_agent.py")

rows = []
for t in tickets():
    a = wf.run(t)
    b = ma.run(t)
    rows.append({
        "ticket_id": t["ticket_id"],
        "workflow": a["decision"], "workflow_steps": a["steps"],
        "multi_agent": b["结论"], "role": b["role"],
        "agent_note": "按观察动态选择工具，步数不确定（上限 4）",
    })
report = {
    "tickets": len(rows),
    "workflow": "路径固定 / 成本最低 / 可回归 / 规则可枚举时首选",
    "react_agent": "模型运行时选工具 / 适合信息不全、路径不确定 / 需步数上限与白名单",
    "multi_agent": "多角色互相校验 / 成本最高 / 仅在单 Agent 不足时使用",
    "rows": rows,
}
write_json("unit3/compare_report.json", report)
print("对照完成：%d 条工单 -> compare_report.json" % len(rows))
for r in rows[:4]:
    print("  %-5s %-16s %-10s" % (r["ticket_id"], r["workflow"], r["multi_agent"]))
