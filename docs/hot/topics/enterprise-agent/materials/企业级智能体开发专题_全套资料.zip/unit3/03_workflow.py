# -*- coding: utf-8 -*-
"""单元三 · Workflow：开发者画好的固定 DAG，最便宜、最可回归。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.lc import tickets

from langchain_core.runnables import RunnableBranch, RunnableLambda

validate = RunnableLambda(lambda t: dict(t, valid=bool(t.get("ticket_id"))))
route = RunnableBranch(
    (lambda t: t["risk"] == "high" or t["amount"] >= 2000,
     RunnableLambda(lambda t: dict(t, decision="转人工审批", steps=3))),
    (lambda t: t["days"] > 7 and t["type"] == "无理由退货",
     RunnableLambda(lambda t: dict(t, decision="超出7日，改换货或转人工", steps=3))),
    RunnableLambda(lambda t: dict(t, decision="按制度自动受理", steps=2)),
)
workflow = validate | route

for t in tickets():
    r = workflow.invoke(t)
    print("  %-5s %-12s -> %s" % (r["ticket_id"], r["type"], r["decision"]))
print("\n特点：路径固定、可预测、可写单元测试；适合规则可枚举的场景。")


def run(t):
    return workflow.invoke(t)
