# -*- coding: utf-8 -*-
"""单元三 · ReAct：LangChain create_tool_calling_agent + AgentExecutor 离线跑通。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.lc import ai, scripted, tool_call

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool


@tool
def get_order(order_id: str) -> str:
    """按订单号查询订单状态（只读）。"""
    return {"A100": "已签收 3 天", "A101": "已签收 9 天"}.get(order_id, "订单不存在")


@tool
def policy_lookup(keyword: str) -> str:
    """按关键词查询售后制度条款（只读）。"""
    return "第一条：签收 7 日内可无理由退货；第 8 日起不再受理。"


tools = [get_order, policy_lookup]

# 脚本模型按序给出：先调用工具 -> 观察结果 -> 再给最终答复
model = scripted([
    ai("", [tool_call("get_order", {"order_id": "A100"})]),
    ai("", [tool_call("policy_lookup", {"keyword": "无理由退货"})]),
    ai("依据第一条与订单状态：A100 已签收 3 天，符合 7 日无理由退货条件。"),
])
prompt = ChatPromptTemplate.from_messages([
    ("system", "你是星辰电商售后助手。只能使用给定工具，信息不足时先查工具，不要编造。"),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])
agent = create_tool_calling_agent(model, tools, prompt)
executor = AgentExecutor(
    agent=agent, tools=tools,
    max_iterations=4,           # 步数硬上限，防止死循环
    return_intermediate_steps=True,
    handle_parsing_errors=True,
)
r = executor.invoke({"input": "订单 A100 签收 3 天还能退吗"})
print("最终答复：", r["output"])
print("执行步数：", len(r["intermediate_steps"]))
for action, obs in r["intermediate_steps"]:
    print("  tool=%-14s args=%s -> %s" % (action.tool, action.tool_input, str(obs)[:44]))
print("\n生产替换：scripted(...) -> init_chat_model(...)，并接入 LangGraph 状态图。")


def run(question):
    return executor.invoke({"input": question})
