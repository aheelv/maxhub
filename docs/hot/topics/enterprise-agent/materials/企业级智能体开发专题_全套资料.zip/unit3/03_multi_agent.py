# -*- coding: utf-8 -*-
"""单元三 · Supervisor 多角色：按风险把工单分派给售后/风控，再汇总。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.lc import tickets

from langchain_core.runnables import RunnableBranch, RunnableLambda

售后 = RunnableLambda(lambda t: {"role": "售后专员", "意见": "符合制度，可受理", "ticket": t["ticket_id"]})
风控 = RunnableLambda(lambda t: {"role": "风控专员", "意见": "金额较大/越权，需人工复核", "ticket": t["ticket_id"]})
主管 = RunnableBranch(
    (lambda t: t["risk"] == "high" or t["amount"] >= 2000, 风控),
    售后,
)
汇总 = RunnableLambda(lambda x: dict(x, 结论=("转人工" if x["role"] == "风控专员" else "自动受理")))
crew = 主管 | 汇总

for t in tickets()[:6]:
    r = crew.invoke(t)
    print("  %-5s risk=%-4s -> %s / %s / %s" % (
        r["ticket"], t["risk"], r["role"], r["意见"][:12], r["结论"]))
print("\n注意：先证明单 Agent 不够用，再引入多角色；多角色成本与不确定性更高。")


def run(t):
    return crew.invoke(t)
