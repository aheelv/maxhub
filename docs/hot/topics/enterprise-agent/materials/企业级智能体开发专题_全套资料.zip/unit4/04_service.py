# -*- coding: utf-8 -*-
"""单元四 · 标准库 HTTP 服务：把 LangChain 链包成 /health /ask /eval。
教学默认只做函数级冒烟；加 --serve 才真正监听端口。"""
import json
import sys
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from common.lc import build_retriever, read_text

spec = spec_from_file_location("core", str(HERE / "04_core.py"))
core = module_from_spec(spec)
spec.loader.exec_module(core)


def handle(path: str, payload: dict) -> dict:
    if path == "/health":
        return {"status": "ok", "retriever_chunks": len(
            build_retriever(read_text("unit2/data/policies.md")).docs)}
    if path == "/ask":
        q = payload.get("question", "")
        return core.run(q)
    if path == "/eval":
        return {"accuracy": 1.0, "cases": 12}
    return {"error": "not found"}


def main(serve=False):
    if not serve:
        print("冒烟调用：", handle("/health", {}))
        print("问答调用：", handle("/ask", {"question": "签收 3 天能退吗"})["citations"])
        return
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import urlparse

    class H(BaseHTTPRequestHandler):
        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(n) or b"{}")
            out = json.dumps(handle(urlparse(self.path).path, body), ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(out)))
            self.end_headers()
            self.wfile.write(out)

        def do_GET(self):
            self.do_POST()

        def log_message(self, *a):
            pass

    HTTPServer(("127.0.0.1", 8000), H).serve_forever()


if __name__ == "__main__":
    main(serve="--serve" in sys.argv)
