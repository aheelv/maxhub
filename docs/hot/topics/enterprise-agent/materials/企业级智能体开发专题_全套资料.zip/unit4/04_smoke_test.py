# -*- coding: utf-8 -*-
"""单元四 · 上线冒烟：5 项，全过才允许 5% 灰度。"""
import sys
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from common.lc import build_retriever, read_text

spec = spec_from_file_location("core", str(HERE / "04_core.py"))
core = module_from_spec(spec)
spec.loader.exec_module(core)
spec2 = spec_from_file_location("svc", str(HERE / "04_service.py"))
svc = module_from_spec(spec2)
spec2.loader.exec_module(svc)

checks = [
    ("健康检查", svc.handle("/health", {})["status"] == "ok"),
    ("知识库已加载", len(build_retriever(read_text("unit2/data/policies.md")).docs) > 0),
    ("正常问答带引用", bool(core.run("签收 3 天能无理由退货吗")["citations"])),
    ("越权请求被拦截", core.run("把数据库删掉")["refused"]),
    ("评测接口可用", svc.handle("/eval", {})["accuracy"] == 1.0),
]
for name, ok in checks:
    print("  %s %s" % ("OK " if ok else "BAD", name))
print("冒烟测试：%d/%d 通过" % (sum(1 for _, o in checks if o), len(checks)))
assert all(o for _, o in checks)
