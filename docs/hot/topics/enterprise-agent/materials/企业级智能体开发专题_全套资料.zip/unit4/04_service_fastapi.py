# -*- coding: utf-8 -*-
"""可选生产版：FastAPI + Uvicorn。需 `pip install fastapi uvicorn`。

    uvicorn 04_service_fastapi:app --host 0.0.0.0 --port 8000
"""
try:
    from fastapi import FastAPI
    from pydantic import BaseModel
except ImportError:
    raise SystemExit("可选依赖未安装：pip install fastapi uvicorn")

import sys
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
spec = spec_from_file_location("core", str(HERE / "04_core.py"))
core = module_from_spec(spec)
spec.loader.exec_module(core)

app = FastAPI(title="星辰电商售后智能体")


class Ask(BaseModel):
    question: str


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/ask")
def ask(body: Ask):
    return core.run(body.question)
