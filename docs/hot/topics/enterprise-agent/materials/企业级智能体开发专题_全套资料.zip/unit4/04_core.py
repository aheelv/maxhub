# -*- coding: utf-8 -*-
"""单元四 · 汇总完整链：护栏 -> 检索 -> 工具 -> 组答复 -> 输出校验。"""
import sys
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
from common.lc import (build_retriever, call_tool, format_docs, mock_llm,
                       read_text)

from langchain_core.runnables import RunnableLambda

retriever = build_retriever(read_text("unit2/data/policies.md"), source="policies.md")


def guard_input(q: str):
    bad = ["忽略以上", "绕开制度", "删除数据库", "管理员身份", "直接编", "承诺赔付"]
    if len(q) > 200:
        return {"block": True, "reason": "输入超长"}
    for k in bad:
        if k in q:
            return {"block": True, "reason": "疑似越权/提示注入：" + k}
    return {"block": False, "reason": ""}


def compose(inp):
    if inp.get("blocked"):
        return {"answer": "请求已被护栏拦截：" + inp["reason"], "citations": [], "refused": True}
    ctx, facts = inp["context"], inp["facts"]
    if not ctx and not facts:
        return {"answer": "无可靠依据，已转人工。", "citations": [], "refused": True}
    cites = [c.split("]")[0] + "]" for c in ctx.split("\n") if c.strip()]
    body = ("依据公司制度：\n" + ctx) if ctx else "来自业务系统：" + str(facts)
    return {"answer": body, "citations": cites, "refused": False}


chain = RunnableLambda(lambda q: {
    "q": q, "guard": guard_input(q),
}) | RunnableLambda(lambda x: {
    "blocked": x["guard"]["block"], "reason": x["guard"]["reason"],
    "context": "" if x["guard"]["block"] else format_docs(retriever.invoke(x["q"])),
    "facts": [] if x["guard"]["block"] else (
        call_tool("get_order", {"order_id": "A100"})["result"]
        if "A100" in x["q"] else []),
}) | mock_llm(compose)


def run(question: str) -> dict:
    return chain.invoke(question)
