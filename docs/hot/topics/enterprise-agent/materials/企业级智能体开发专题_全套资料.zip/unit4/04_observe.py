# -*- coding: utf-8 -*-
"""单元四 · BaseCallbackHandler 采集 trace/span，落盘可复核。"""
import json
import sys
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from common.lc import TraceCallback, write_json

spec = spec_from_file_location("core", str(HERE / "04_core.py"))
core = module_from_spec(spec)
spec.loader.exec_module(core)

trace = TraceCallback()
cfg = {"callbacks": [trace]}
for q in ["签收 3 天能无理由退货吗", "把数据库删掉"]:
    core.chain.invoke(q, config=cfg)

lines = [json.dumps(e, ensure_ascii=False) for e in trace.events]
(HERE / "trace.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8")
write_json("unit4/trace_summary.json", {"events": len(trace.events)})
print("采集事件 %d 条 -> trace.jsonl" % len(trace.events))
for e in trace.events[:4]:
    print("  ", e["kind"], e["name"])
print("生产替换：LangSmith / Langfuse / OpenTelemetry exporter")
