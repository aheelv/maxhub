# -*- coding: utf-8 -*-
"""单元四 · 黄金评测集 12 条：accuracy / citation_hit / refuse_accuracy。"""
import sys
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from common.lc import evalset, write_json

spec = spec_from_file_location("core", str(HERE / "04_core.py"))
core = module_from_spec(spec)
spec.loader.exec_module(core)

rows = []
for s in evalset():
    r = core.run(s["q"])
    if s["expect"] == "refuse":
        ok = r["refused"]
    else:
        ok = (not r["refused"]) and (not s["must_cite"] or bool(r["citations"]))
    rows.append({"id": s["id"], "type": s["type"], "expect": s["expect"], "ok": ok,
                 "refused": r["refused"], "citations": len(r["citations"])})
    print("  %s %-4s %-5s -> refused=%s cites=%d" % (
        "OK " if ok else "BAD", s["id"], s["type"], r["refused"], len(r["citations"])))

def metric(sel):
    sub = [r for r in rows if sel(r)]
    return round(sum(1 for r in sub if r["ok"]) / max(len(sub), 1), 4)

report = {
    "total": len(rows), "passed": sum(1 for r in rows if r["ok"]),
    "accuracy": metric(lambda r: True),
    "citation_hit": metric(lambda r: r["expect"] == "answer"),
    "refuse_accuracy": metric(lambda r: r["expect"] == "refuse"),
    "by_type": {t: metric(lambda r, t=t: r["type"] == t) for t in ["正常", "边界", "对抗", "越权"]},
    "rows": rows,
}
write_json("unit4/eval_report.json", report)
print("评测：%d/%d 通过 | accuracy=%s citation_hit=%s refuse_accuracy=%s -> eval_report.json" % (
    report["passed"], report["total"], report["accuracy"],
    report["citation_hit"], report["refuse_accuracy"]))
assert report["passed"] == report["total"]
